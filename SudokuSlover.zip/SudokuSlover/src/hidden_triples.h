#pragma once

#include "sudoku.h"

int hidden_triples(SudokuBoard *p_board);