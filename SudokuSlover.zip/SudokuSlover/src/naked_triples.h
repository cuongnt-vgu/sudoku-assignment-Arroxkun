#pragma once

#include "sudoku.h"

int naked_triples(SudokuBoard *p_board);