#include "hidden_triples.h"

int hidden_triples(SudokuBoard *p_board)
{
    return 0;
}