#pragma once

#include "sudoku.h"

int naked_pairs(SudokuBoard *p_board);