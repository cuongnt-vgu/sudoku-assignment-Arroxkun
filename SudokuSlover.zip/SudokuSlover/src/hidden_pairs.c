#include "hidden_pairs.h"

int hidden_pairs(SudokuBoard *p_board)
{
    return 0;
}
