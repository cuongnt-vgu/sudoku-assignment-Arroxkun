#pragma once

#include "sudoku.h"

int hidden_pairs(SudokuBoard *p_board);
