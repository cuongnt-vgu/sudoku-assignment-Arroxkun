#include "naked_triples.h"

int naked_triples(SudokuBoard *p_board)
{
    return 0;
}