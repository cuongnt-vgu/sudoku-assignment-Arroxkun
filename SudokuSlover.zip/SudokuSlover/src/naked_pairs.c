#include "naked_pairs.h"

int naked_pairs(SudokuBoard *p_board)
{
    return 0;
}